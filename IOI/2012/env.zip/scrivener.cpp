
char last;

void Init() {}

void TypeLetter(char L) {

  last = L;

}

void UndoCommands(int U) {

}

char GetLetter(int P) {

  return last;

}
